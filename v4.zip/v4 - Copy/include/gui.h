#ifndef GUI_H
#define GUI_H

//extern int auton_sel;
void gui(void);

#endif // GUI_H
