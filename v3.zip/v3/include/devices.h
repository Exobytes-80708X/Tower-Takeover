#include "main.h"
extern pros::Controller controller;
extern pros::Motor leftRoller;
extern pros::Motor trayMotor;
extern pros::Motor armMotor;
extern pros::Motor rightRoller;
extern pros::ADIAnalogIn trayPot;
extern pros::ADIAnalogIn armPot;
extern okapi::MotorGroup leftDrive;
extern okapi::MotorGroup rightDrive;
