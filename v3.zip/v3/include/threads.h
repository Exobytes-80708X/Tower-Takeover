#include "main.h"
using namespace okapi;

void thread_arm(void* param);
void thread_intake(void* param);
void thread_tray(void* param);
void thread_control(void* param);
void odometry_debug(void* param);
extern int reqTrayPos;
extern int currentTrayPos;
extern bool trayResting;
extern int reqArmPos;
extern int currentArmPos;
extern int intakeState;
extern const int holding;
extern const int intake;
extern const int outtake;
extern const int coasting;
extern const int armNeutral;
extern const int armUp;
extern const int trayNeutral;
extern const int trayHalfOut;
extern const int trayFullOut;
extern double traykP_rev;
extern double traykP_fwd;
extern double armkP;
