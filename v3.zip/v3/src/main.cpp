#include "main.h"

auto myChassis = ChassisControllerFactory::create(
  {9,8}, // Left motors
  {-7,-6},   // Right motors
  AbstractMotor::gearset::green,
  {5.33_in,10.5_in}
);

auto profileControllerSlow = AsyncControllerFactory::motionProfile(
  0.5,  // Maximum linear velocity of the Chassis in m/s
  1.2,  // Maximum linear acceleration of the Chassis in m/s/s
  8.0, // Maximum linear jerk of the Chassis in m/s/s/s
  myChassis // Chassis Controller
);

auto profileControllerFast = AsyncControllerFactory::motionProfile(
  2.0,  // Maximum linear velocity of the Chassis in m/s
  10.0,  // Maximum linear acceleration of the Chassis in m/s/s
  10.0, // Maximum linear jerk of the Chassis in m/s/s/s
  myChassis // Chassis Controller
);

void thread_drive(void* param)
{
	while(true)
	{
		if(controller.get_digital(pros::E_CONTROLLER_DIGITAL_R1)) {
			leftDrive.moveVelocity(controller.get_analog(ANALOG_LEFT_Y)/2.5);
      rightDrive.moveVelocity(controller.get_analog(ANALOG_RIGHT_Y)/2.5);
    }
		else
			myChassis.tank(controller.get_analog(ANALOG_LEFT_Y)/127.0, controller.get_analog(ANALOG_RIGHT_Y)/127.0, 0.1);
	}
}

//----------GUI----------
lv_obj_t * autonSelectText;
lv_obj_t * autonBlue1Button;
lv_obj_t * autonBlue1ButtonLabel;
lv_obj_t * autonRed1Button;
lv_obj_t * autonRed1ButtonLabel;
lv_obj_t * pathGenerationLabel = lv_label_create(lv_scr_act(), NULL);
//-----------------------


//--------------ODOM-----------------
const double WHEEL_CIRCUMFERENCE = 4*PI;
const double BACK_TO_TRACKING_LENGTH = 5;
const double RIGHT_TO_TRACKING_LENGTH = 5;
const double DELAY = 5;
double currentLeft = 0;
double currentRight = 0;
double currentBack = 0;
double dLeftVal = 0;
double dRightVal = 0;
double dBackVal = 0;
double prevLeft = 0;
double prevRight = 0;
double prevBack = 0;
double dTheta = 0;
double absTheta = 0;
double prevTheta = 0;
double robotTheta = 0;
double dX = 0;
double dY = 0;
double dOffsetX = 0;
double dOffsetY = 0;
double avgTheta = 0;
double robotX = 0;
double robotY = 0;

double inchesTraveled(double encoderTicks)
{
    return (encoderTicks / 360)*WHEEL_CIRCUMFERENCE;
}

/*void thread_odometry(void* param){

   leftEnc.reset();
   rightEnc.reset();
   pros::delay(50);
   while(true)
   {
       currentLeft = inchesTraveled(leftEnc.get_value()); //read encoders
       currentRight = inchesTraveled(rightEnc.get_value());
       currentBack = inchesTraveled(backEnc.get_value());
       dLeftVal = (currentLeft - prevLeft);
       dRightVal = (currentRight - prevRight);
       dBackVal = (currentBack - prevBack);

       prevLeft = currentLeft; //update prev values
       prevRight = currentRight;
       prevBack = currentBack;
       dTheta = (dLeftVal - dRightVal) / (RIGHT_TO_TRACKING_LENGTH * 2); //calculate change in angle in radians
       absTheta = prevTheta + dTheta;

       robotTheta += dTheta;
       robotTheta = fmod(robotTheta, 2*M_PI);
       if(robotTheta < 0) robotTheta += 2*M_PI;

       dX = (dLeftVal + dRightVal)/2 * sin( (robotTheta) ); //calculate change in x
       dY = (dLeftVal + dRightVal)/2 * cos( (robotTheta) ); //calculate change in y
       if(dTheta == 0){
         dOffsetX = dBackVal;
         dOffsetY = dRightVal;
       } else{

         dOffsetX = 2 * sin(dTheta/2) * ((dBackVal/dTheta) + BACK_TO_TRACKING_LENGTH);
         dOffsetY = 2 * sin(dTheta/2) * ((dRightVal/dTheta) + RIGHT_TO_TRACKING_LENGTH);
       }

         avgTheta = prevTheta + (dTheta/2);
         double r = sqrt(pow(dOffsetX,2) + pow(dOffsetY,2));
         double tempTheta = acos(dOffsetX/r);
         dX = r*cos(tempTheta + avgTheta);
         dY = r*sin(tempTheta + avgTheta);
         robotX+=dX;
         robotY+=dY;

       pros::delay(DELAY); //reupdate every dT msec
   }
}*/



//----------------------------------------------

void unfold()
{
  intakeState = coasting;
  reqTrayPos = trayHalfOut;
  reqArmPos = 1400;
  pros::delay(1000);
  reqTrayPos = trayNeutral;
  reqArmPos = armNeutral;
  pros::delay(500);
}


void flipDrive(bool dir) //true is forward, false is back
{
  if(dir) {
    auto myChassis = ChassisControllerFactory::create(
      {9,8}, // Left motors
      {-7,-6},   // Right motors
      AbstractMotor::gearset::green,
      {5.33_in,10.5_in}
    );
  }
  else {
    auto myChassis = ChassisControllerFactory::create(
      {7,6}, // Left motors
      {-9,-8},   // Right motors
      AbstractMotor::gearset::green,
      {5.33_in,10.5_in}
    );
  }
}


//----------------------------------------------

/**
 * Runs initialization code. This occurs as soon as the program is started.
 *
 * All other competition modes are blocked by initialize; it is recommended
 * to keep execution time for this mode under a few seconds.
 */


 static lv_res_t autonBlue1ButtonAction(lv_obj_t * btn)
 {
   lv_label_set_text(pathGenerationLabel, "Path Generating");

   profileControllerSlow.generatePath({
     Point{0_ft, 0_ft, 0_deg},  // Profile starting position, this will normally be (0, 0, 0)
     Point{3.5_ft, 0_ft, 0_deg}},
     "A" // Profile name
   );

   profileControllerFast.generatePath({
     Point{3.5_ft, 0_ft, 0_deg},
     Point{0_ft, 2_ft, 0_deg}},
     "B"
   );

   profileControllerSlow.generatePath({
     Point{0_ft, 0_ft, 0_deg},
     Point{3.5_ft, 0_ft, 0_deg}},
     "C"
   );

   profileControllerFast.generatePath({
     Point{0_ft, 0_ft, 0_deg},
     Point{2.5_ft, 0_ft, 0_deg}},
     "D"
   );

   lv_label_set_text(pathGenerationLabel, "Path Generation Complete");

   return LV_RES_OK;
 }

 static lv_res_t autonRed1ButtonAction(lv_obj_t * btn)
 {
   lv_label_set_text(pathGenerationLabel, "Path Generating");
   lv_label_set_text(pathGenerationLabel, "");
   lv_label_set_text(pathGenerationLabel, "Path Generation Complete");

   return LV_RES_OK;
 }

void initialize() {
  pros::Task task_01 (thread_arm, 		(void*)"PROS", TASK_PRIORITY_DEFAULT, TASK_STACK_DEPTH_DEFAULT, "Arm positioning");
  pros::Task task_02 (thread_tray, 		(void*)"PROS", TASK_PRIORITY_DEFAULT, TASK_STACK_DEPTH_DEFAULT, "Tray positioning");
  pros::Task task_03 (thread_intake, 	(void*)"PROS", TASK_PRIORITY_DEFAULT, TASK_STACK_DEPTH_DEFAULT, "Intake Control");

  //----------Gui----------

   lv_obj_t *label = lv_label_create(lv_scr_act(), NULL);
   lv_label_set_text(label, "Select Autonomous");
   lv_obj_align(label, NULL, LV_ALIGN_IN_TOP_MID, 0, 0);

   pathGenerationLabel = lv_label_create(lv_scr_act(), NULL);
   lv_label_set_text(pathGenerationLabel, "No Path");
   lv_obj_align(pathGenerationLabel, NULL, LV_ALIGN_IN_BOTTOM_MID, 0, 0);

   autonBlue1Button = lv_btn_create(lv_scr_act(), NULL);
   lv_cont_set_fit(autonBlue1Button, true, true); /*Enable resizing horizontally and vertically*/
   lv_obj_align(autonBlue1Button, NULL, LV_ALIGN_IN_LEFT_MID, 50, 50);
   lv_obj_set_free_num(autonBlue1Button, 1);
   lv_btn_set_action(autonBlue1Button, LV_BTN_ACTION_CLICK, autonBlue1ButtonAction);

   label = lv_label_create(autonBlue1Button, NULL);
   lv_label_set_text(label, "Blue Side Auton 1");

   //

   pathGenerationLabel = lv_label_create(lv_scr_act(), NULL);
   lv_label_set_text(pathGenerationLabel, "No Path");
   lv_obj_align(pathGenerationLabel, NULL, LV_ALIGN_IN_BOTTOM_MID, 0, 0);

   autonRed1Button = lv_btn_create(lv_scr_act(), NULL);
   lv_cont_set_fit(autonRed1Button, true, true); /*Enable resizing horizontally and vertically*/
   lv_obj_align(autonRed1Button, NULL, LV_ALIGN_IN_RIGHT_MID, 50, 50);
   lv_obj_set_free_num(autonRed1Button, 1);
   lv_btn_set_action(autonRed1Button, LV_BTN_ACTION_CLICK, autonRed1ButtonAction);

   label = lv_label_create(autonRed1Button, NULL);
   lv_label_set_text(label, "Red Side Auton 1");
  //-----------------------
}

/**
 * Runs while the robot is in the disabled state of Field Management System or
 * the VEX Competition Switch, following either autonomous or opcontrol. When
 * the robot is enabled, this task will exit.
 */
void disabled()
{}

/**
 * Runs after initialize(), and before autonomous when connected to the Field
 * Management System or the VEX Competition Switch. This is intended for
 * competition-specific initialization routines, such as an autonomous selector
 * on the LCD.
 *
 * This task will exit when the robot is enabled and autonomous or opcontrol
 * starts.
 */
void competition_initialize()
{}
/**
 * Runs the user autonomous code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the autonomous
 * mode. Alternatively, this function may be called in initialize or opcontrol
 * for non-competition testing purposes.
 *
 * If the robot is disabled or communications is lost, the autonomous task
 * will be stopped. Re-enabling the robot will restart the task, not re-start it
 * from where it left off.
 */
void autonomous()
{
  unfold();

  intakeState = intake;

  profileControllerSlow.setTarget("A");

  profileControllerSlow.waitUntilSettled();

  profileControllerSlow.removePath("A");

  flipDrive(0);

  intakeState = holding;

  profileControllerFast.setTarget("B");

  profileControllerFast.waitUntilSettled();

  flipDrive(1);

  intakeState = intake;

  profileControllerSlow.setTarget("C");

  profileControllerSlow.waitUntilSettled();

  intakeState = holding;

  flipDrive(1);

  myChassis.setMaxVelocity(50);

  myChassis.turnAngle(160_deg);

  myChassis.setMaxVelocity(200);

  profileControllerFast.setTarget("D");

  profileControllerFast.waitUntilSettled();

  reqTrayPos = trayFullOut;
  intakeState = coasting;

  pros::delay(1500);

  myChassis.moveDistance(-0.5_ft);
}
/**
 * Runs the operator control code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the operator
 * control mode.
 *
 * If no competition control is connected, this function will run immediately
 * following initialize().
 *
 * If the robot is disabled or communications is lost, the
 * operator control task will be stopped. Re-enabling the robot will restart the
 * task, not resume it from where it left off.
 */
void opcontrol() {
  pros::Task task_04 (thread_control, (void*)"PROS", TASK_PRIORITY_DEFAULT, TASK_STACK_DEPTH_DEFAULT, "For opcontrol ONLY");
  pros::Task task_05 (thread_drive, 	(void*)"PROS", TASK_PRIORITY_DEFAULT, TASK_STACK_DEPTH_DEFAULT, "For opcontrol ONLY");
}
