#include "main.h"
int auton = 0;


auto myChassis = ChassisControllerFactory::create(
  leftDrive, // Left motors
  rightDrive,   // Right motors
  AbstractMotor::gearset::green,
  {5.33_in,10.5_in}
);

auto profileControllerSlow = AsyncControllerFactory::motionProfile(
  0.5,  // Maximum linear velocity of the Chassis in m/s
  1.2,  // Maximum linear acceleration of the Chassis in m/s/s
  8.0, // Maximum linear jerk of the Chassis in m/s/s/s
  myChassis // Chassis Controller
);

auto profileControllerFast = AsyncControllerFactory::motionProfile(
  2.0,  // Maximum linear velocity of the Chassis in m/s
  10.0,  // Maximum linear acceleration of the Chassis in m/s/s
  10.0, // Maximum linear jerk of the Chassis in m/s/s/s
  myChassis // Chassis Controller
);

void thread_drive(void* param)
{
	while(true)
	{
		if(controller.get_digital(pros::E_CONTROLLER_DIGITAL_R1)) {
			leftDrive.moveVelocity(controller.get_analog(ANALOG_LEFT_Y)/1.75);
      rightDrive.moveVelocity(controller.get_analog(ANALOG_RIGHT_Y)/1.75);
    }
		else
			myChassis.tank(controller.get_analog(ANALOG_LEFT_Y)/127.0, controller.get_analog(ANALOG_RIGHT_Y)/127.0, 0.1);
	}
}

//----------GUI----------
lv_obj_t * autonSelectText;
lv_obj_t * autonBlue1Button;
lv_obj_t * autonBlue2Button;
lv_obj_t * autonBlue1ButtonLabel;
lv_obj_t * autonRed1Button;
lv_obj_t * autonRed2Button;
lv_obj_t * autonRed1ButtonLabel;
lv_obj_t * pathGenerationLabel;
//-----------------------

void unfold()
{
  traykP_rev = 0.1;
  armkP = 0.5;
  intakeState = coasting;
  reqTrayPos = trayHalfOut;
  reqArmPos = 1400;
  pros::delay(750);
  reqTrayPos = trayNeutral;
  reqArmPos = armNeutral;
  //pros::delay(500);
  traykP_rev = 0.03;
  armkP = 0.25;
}


void flipDrive(bool dir) //true is forward, false is back
{
  if(dir) {
    auto myChassis = ChassisControllerFactory::create(
      {9,8}, // Left motors
      {-7,-6},   // Right motors
      AbstractMotor::gearset::green,
      {5.33_in,10.5_in}
    );
  }
  else {
    auto myChassis = ChassisControllerFactory::create(
      {7,6}, // Left motors
      {-9,-8},   // Right motors
      AbstractMotor::gearset::green,
      {5.33_in,10.5_in}
    );
  }
}

 lv_obj_t* createBtn(lv_obj_t * parent, lv_coord_t x, lv_coord_t y, lv_coord_t width, lv_coord_t height, int id, const char* title)
 {
   parent = lv_btn_create(lv_scr_act(), NULL);
   lv_obj_set_pos(parent, x, y);
   lv_obj_set_size(parent,width,height);
   lv_obj_set_free_num(parent, id);

   lv_obj_t * label = lv_label_create(parent, NULL);
   lv_label_set_text(label, title);

   return parent;
 }

 void createTextLabel(lv_obj_t * parent, const char* text, lv_coord_t x, lv_coord_t y)
 {
   parent = lv_label_create(lv_scr_act(), NULL);
   lv_label_set_text(parent,text);
   lv_obj_set_pos(parent,x,y);
 }

 void createVarLabel(lv_obj_t * parent, double var, lv_coord_t x, lv_coord_t y)
 {
   parent = lv_label_create(lv_scr_act(), NULL);
   std::string s = std::to_string( var );
   char s_array[s.length()+1];
   strcpy(s_array,s.c_str());
   lv_label_set_text(parent,s_array);
   lv_obj_set_pos(parent,x,y);
 }

void updateVarLabel(lv_obj_t * parent, double var)
{
  std::string s = std::to_string( var );
  char s_array[s.length()+1];
  strcpy(s_array,s.c_str());
  lv_label_set_text(parent,s_array);
}

 static lv_res_t autonRed1ButtonAction(lv_obj_t * btn)
 {
   auton = 0;
   profileControllerSlow.generatePath({
     Point{0_ft, 0_ft, 0_deg},  // Profile starting position, this will normally be (0, 0, 0)
     Point{3.5_ft, 0_ft, 0_deg}},
     "A" // Profile name
   );

   profileControllerFast.generatePath({
     Point{3.5_ft, 0_ft, 0_deg},
     Point{0_ft, 1.85_ft, 0_deg}},
     "B"
   );

   profileControllerSlow.generatePath({
     Point{0_ft, 0_ft, 0_deg},
     Point{3.25_ft, 0_ft, 0_deg}},
     "C"
   );

   profileControllerFast.generatePath({
     Point{0_ft, 0_ft, 0_deg},
     Point{-2_ft, 0.5_ft, 0_deg}},
     "D"
   );

   lv_label_set_text(pathGenerationLabel, "Path Generation Complete [Red 7]");
   lv_obj_align(pathGenerationLabel, NULL, LV_ALIGN_IN_BOTTOM_MID, 0, 0);
   return LV_RES_OK;
 }

 static lv_res_t autonBlue1ButtonAction(lv_obj_t * btn)
 {
   auton = 1;
   profileControllerSlow.generatePath({
     Point{0_ft, 0_ft, 0_deg},  // Profile starting position, this will normally be (0, 0, 0)
     Point{3.5_ft, 0_ft, 0_deg}},
     "A" // Profile name
   );

   profileControllerFast.generatePath({
     Point{3.5_ft, 0_ft, 0_deg},
     Point{0_ft, -1.85_ft, 0_deg}},
     "B"
   );

   profileControllerSlow.generatePath({
     Point{0_ft, 0_ft, 0_deg},
     Point{3.25_ft, 0_ft, 0_deg}},
     "C"
   );

   profileControllerFast.generatePath({
     Point{0_ft, 0_ft, 0_deg},
     Point{-2_ft, -0.5_ft, 0_deg}},
     "D"
   );

   lv_label_set_text(pathGenerationLabel, "Path Generation Complete [Blue 7]");
   lv_obj_align(pathGenerationLabel, NULL, LV_ALIGN_IN_BOTTOM_MID, 0, 0);
   return LV_RES_OK;
   return LV_RES_OK;
 }

 static lv_res_t autonRed2ButtonAction(lv_obj_t * btn)
 {
   auton = 2;
   profileControllerSlow.generatePath({
     Point{0_ft, 0_ft, 0_deg},  // Profile starting position, this will normally be (0, 0, 0)
     Point{3.5_ft, 0_ft, 0_deg}},
     "A" // Profile name
   );

   profileControllerFast.generatePath({
     Point{0_ft, 0_ft, 0_deg},
     Point{-2_ft, 0.5_ft, 0_deg}},
     "D"
   );

   lv_label_set_text(pathGenerationLabel, "Path Generation Complete [Red 5]");
   lv_obj_align(pathGenerationLabel, NULL, LV_ALIGN_IN_BOTTOM_MID, 0, 0);
   return LV_RES_OK;
   return LV_RES_OK;
 }

 static lv_res_t autonBlue2ButtonAction(lv_obj_t * btn)
 {
   auton = 3;
   profileControllerSlow.generatePath({
     Point{0_ft, 0_ft, 0_deg},  // Profile starting position, this will normally be (0, 0, 0)
     Point{4_ft, 0_ft, 0_deg}},
     "A" // Profile name
   );

   profileControllerFast.generatePath({
     Point{0_ft, 0_ft, 0_deg},
     Point{-3_ft, -0.5_ft, 0_deg}},
     "D"
   );

   lv_label_set_text(pathGenerationLabel, "Path Generation Complete [Blue 5]");
   lv_obj_align(pathGenerationLabel, NULL, LV_ALIGN_IN_BOTTOM_MID, 0, 0);
   return LV_RES_OK;
   return LV_RES_OK;
 }

void initialize() {

  pros::Task task_01 (thread_arm, 		(void*)"PROS", TASK_PRIORITY_DEFAULT, TASK_STACK_DEPTH_DEFAULT, "Arm positioning");
  pros::Task task_02 (thread_tray, 		(void*)"PROS", TASK_PRIORITY_DEFAULT, TASK_STACK_DEPTH_DEFAULT, "Tray positioning");
  pros::Task task_03 (thread_intake, 	(void*)"PROS", TASK_PRIORITY_DEFAULT, TASK_STACK_DEPTH_DEFAULT, "Intake Control");
  //pros::Task odom_debug(thread_Odometry, (void*)"PROS" ,TASK_PRIORITY_DEFAULT, TASK_STACK_DEPTH_DEFAULT, "odometry debugging");
  //----------Gui----------
  pathGenerationLabel = lv_label_create(lv_scr_act(), NULL);
  lv_label_set_text(pathGenerationLabel,"No Path" );
  lv_obj_align(pathGenerationLabel, NULL, LV_ALIGN_IN_BOTTOM_MID, 0, 0);

   lv_obj_t *label = lv_label_create(lv_scr_act(), NULL);
   lv_label_set_text(label, "Select Autonomous");
   lv_obj_align(label, NULL, LV_ALIGN_IN_TOP_MID, 0, 0);

   lv_btn_set_action(createBtn(autonBlue1Button,25,25,150,75,1,"Red Side [7]"),LV_BTN_ACTION_CLICK, autonRed1ButtonAction);
   lv_btn_set_action(createBtn(autonRed1Button,255,25,150,75,2,"Blue Side [7]"),LV_BTN_ACTION_CLICK, autonBlue1ButtonAction);
   lv_btn_set_action(createBtn(autonRed2Button,25,125,150,75,3,"Red Side [5]"),LV_BTN_ACTION_CLICK, autonRed2ButtonAction);
   lv_btn_set_action(createBtn(autonBlue2Button,255,125,150,75,4,"Blue Side [5]"),LV_BTN_ACTION_CLICK, autonBlue2ButtonAction);

}


/**
 * Runs while the robot is in the disabled state of Field Management System or
 * the VEX Competition Switch, following either autonomous or opcontrol. When
 * the robot is enabled, this task will exit.
 */
void disabled()
{}

/**
 * Runs after initialize(), and before autonomous when connected to the Field
 * Management System or the VEX Competition Switch. This is intended for
 * competition-specific initialization routines, such as an autonomous selector
 * on the LCD.
 *
 * This task will exit when the robot is enabled and autonomous or opcontrol
 * starts.
 */
void competition_initialize()
{}

void autonomous()
{
  /*myChassis.turnAngle(calcAngleError(-24,0)*radian);
  pros::delay(500);
  myChassis.turnAngle(calcAngleError(-24,24)*radian);
  pros::delay(500);
  myChassis.turnAngle(calcAngleError(-0,24)*radian);*/
  switch(auton)
  {
    case 0:
      unfold();

      intakeState = intake;

      profileControllerSlow.setTarget("A");

      profileControllerSlow.waitUntilSettled();

      profileControllerSlow.removePath("A");

      flipDrive(0);

      intakeState = holding;

      profileControllerFast.setTarget("B");

      profileControllerFast.waitUntilSettled();

      flipDrive(1);

      intakeState = intake;

      profileControllerSlow.setTarget("C");

      profileControllerSlow.waitUntilSettled();

      intakeState = holding;

      flipDrive(0);

      profileControllerFast.setTarget("D");

      profileControllerFast.waitUntilSettled();

      flipDrive(1);

      myChassis.setMaxVelocity(80);

      myChassis.turnAngle(135_deg);

      myChassis.setMaxVelocity(50);

      myChassis.moveDistance(0.6_ft);

      intakeState = coasting;
      reqTrayPos = trayFullOut;
      pros::delay(2000);

      myChassis.moveDistance(-1_ft);
      break;

    case 1:
      unfold();

      intakeState = intake;

      profileControllerSlow.setTarget("A");

      profileControllerSlow.waitUntilSettled();

      profileControllerSlow.removePath("A");

      flipDrive(0);

      intakeState = holding;

      profileControllerFast.setTarget("B");

      profileControllerFast.waitUntilSettled();

      flipDrive(1);

      intakeState = intake;

      profileControllerSlow.setTarget("C");

      profileControllerSlow.waitUntilSettled();

      intakeState = holding;

      flipDrive(0);

      profileControllerFast.setTarget("D");

      profileControllerFast.waitUntilSettled();

      flipDrive(1);

      myChassis.setMaxVelocity(80);

      myChassis.turnAngle(-135_deg);

      myChassis.setMaxVelocity(50);

      myChassis.moveDistance(0.6_ft);

      intakeState = coasting;
      reqTrayPos = trayFullOut;
      pros::delay(2000);

      myChassis.moveDistance(-1_ft);
      break;

    case 3:
      unfold();

      intakeState = intake;

      profileControllerSlow.setTarget("A");

      profileControllerSlow.waitUntilSettled();

      profileControllerSlow.removePath("A");

      flipDrive(0);
      intakeState = holding;

      profileControllerFast.setTarget("D");

      profileControllerFast.waitUntilSettled();

      flipDrive(1);

      myChassis.setMaxVelocity(80);

      myChassis.turnAngle(-135_deg);

      myChassis.setMaxVelocity(50);

      myChassis.moveDistance(0.6_ft);

      intakeState = outtake;
      pros::delay(100);
      intakeState = coasting;
      reqTrayPos = trayFullOut;
      pros::delay(2000);

      myChassis.moveDistance(-1_ft);
      break;
  }
}
void opcontrol() {
  pros::Task task_04 (thread_control, (void*)"PROS", TASK_PRIORITY_DEFAULT, TASK_STACK_DEPTH_DEFAULT, "For opcontrol ONLY");
  pros::Task task_05 (thread_drive, 	(void*)"PROS", TASK_PRIORITY_DEFAULT, TASK_STACK_DEPTH_DEFAULT, "For opcontrol ONLY");
}
