#include "main.h"

//----------POTENTIOMETERS-----------
const int armNeutral 	= 475;
const int armHalfUp 	= 1500;
const int armUp 			= 1700;
const int trayNeutral = 2800;
const int trayHalfOut = 2400;
const int trayFullOut = 800;
//--------------------------------------Device Declarations------------------------------------

int currentArmPos = armPot.get_value();
int reqArmPos = armNeutral;
double armkP = 0.25;
void thread_arm(void* param)
{
	const int threshold = 10;
	int error;
	double reqSpeed;
  double maxSpeed = 100;
	while(true)
	{
		currentArmPos = armPot.get_value();
		if(currentArmPos > reqArmPos + threshold || currentArmPos < reqArmPos - threshold)
		{
			error = currentArmPos - reqArmPos; //negative error means move up, positive error means move down
			reqSpeed = -error*armkP;
      if(reqSpeed > maxSpeed)
        reqSpeed = maxSpeed;
      else if(reqSpeed < -maxSpeed)
        reqSpeed = -maxSpeed;
			armMotor.move_velocity(reqSpeed);
		}
		else if(reqArmPos == armNeutral)
		{
			armMotor.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
			armMotor.move_velocity(0);
			while(reqArmPos == armNeutral) pros::delay(10);
		}
    else {
			armMotor.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
			armMotor.move_velocity(0);
		}
    pros::delay(10);
	}
}

int reqTrayPos = trayNeutral;
int currentTrayPos = trayPot.get_value();
bool trayResting = true;
double traykP_rev = 0.03;
double traykP_fwd = 0.5;
void thread_tray(void* param)
{
	const int threshold = 50;
	int error;
	double reqSpeed;
	double maxSpeed = 100;
	while(true)
	{
		currentTrayPos = trayPot.get_value();
		if(currentTrayPos > reqTrayPos + threshold || currentTrayPos < reqTrayPos - threshold)
		{
			trayResting = false;
			error = currentTrayPos - reqTrayPos; //negative error means move up, positive error means move down
			if(error < 0)
				reqSpeed = error*traykP_fwd;
			else
				reqSpeed = error*traykP_rev;
      if(reqSpeed > maxSpeed)
        reqSpeed = maxSpeed;
      else if(reqSpeed < -maxSpeed)
        reqSpeed = -maxSpeed;
			trayMotor.move_velocity(reqSpeed);
		}
		else if(reqArmPos == armNeutral)
		{
			trayMotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);
			trayMotor.move_velocity(0);
			trayResting = true;
		}
    else {
			trayMotor.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
			trayMotor.move_velocity(0);
		}
    pros::delay(10);
	}
}

int intakeState = 0;
const int holding = 0;
const int intake = 2;
const int outtake = 1;
const int coasting = 3;
void thread_intake(void* param)
{
  while(true) {
  switch(intakeState) {
      case 0:
        leftRoller.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
        rightRoller.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
				leftRoller.move_velocity(0);
        rightRoller.move_velocity(0);
        break;
      case 1:
        leftRoller.move_velocity(100);
        rightRoller.move_velocity(100);
        break;
      case 2:
				leftRoller.move_velocity(-200);
				rightRoller.move_velocity(-200);
        break;
      case 3:
        leftRoller.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);
        rightRoller.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);
				leftRoller.move_velocity(0);
        rightRoller.move_velocity(0);
        break;
    }
    pros::delay(10);
  }
}

void thread_control(void* param)
{
  while(true)
  {
    if(controller.get_digital(pros::E_CONTROLLER_DIGITAL_L1))
      intakeState = intake;
    else if(controller.get_digital(pros::E_CONTROLLER_DIGITAL_L2))
      intakeState = outtake;
		else if(currentTrayPos < 2700)
			intakeState = coasting;
    else
      intakeState = holding;

    if(controller.get_digital(pros::E_CONTROLLER_DIGITAL_UP))
    {
      reqTrayPos = trayFullOut;
      intakeState = coasting;
      while(!trayResting && !controller.get_digital(pros::E_CONTROLLER_DIGITAL_DOWN))
        pros::delay(10);
    }
    if(controller.get_digital(pros::E_CONTROLLER_DIGITAL_DOWN)) {
      intakeState = coasting;
      reqTrayPos = trayNeutral;
      while(!trayResting)
        pros::delay(10);
    }

    if(controller.get_digital(pros::E_CONTROLLER_DIGITAL_X))
    {
			traykP_rev = 0.1;
      intakeState = holding;
      reqArmPos = armUp;
      reqTrayPos = trayHalfOut;
    }
    if(controller.get_digital(pros::E_CONTROLLER_DIGITAL_B))
    {
			traykP_rev = 0.03;
      intakeState = holding;
      reqArmPos = armNeutral;
      while(currentArmPos > 1000)
        pros::delay(10);
      reqTrayPos = trayNeutral;
      pros::delay(500);
    }
		if(controller.get_digital(pros::E_CONTROLLER_DIGITAL_A))
    {
			traykP_rev = 0.1;
			intakeState = holding;
      reqArmPos = armHalfUp;
      reqTrayPos = trayHalfOut;
    }
		if(controller.get_digital(pros::E_CONTROLLER_DIGITAL_Y))
    {
			unfold();
    }
  }
}

void odometry_debug(void* param)
{
	pros::delay(100);
	lv_obj_t * xLabel;
	lv_obj_t * yLabel;
	lv_obj_t * thetaLabel;
	createVarLabel(xLabel,robotX,10,20);
	createVarLabel(yLabel,robotY,10,40);
	createVarLabel(thetaLabel,robotTheta,10,60);
	while(true)
	{
		updateVarLabel(xLabel, robotX);
		updateVarLabel(yLabel, robotY);
		updateVarLabel(thetaLabel, robotTheta);
		pros::delay(10);
	}
}
