#include "main.h"
pros::Controller controller(pros::E_CONTROLLER_MASTER);
pros::Motor leftRoller (1, pros::E_MOTOR_GEARSET_18, false, pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor trayMotor (2, pros::E_MOTOR_GEARSET_36, false, pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor armMotor (5, pros::E_MOTOR_GEARSET_36, true, pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor rightRoller (4, pros::E_MOTOR_GEARSET_18, true, pros::E_MOTOR_ENCODER_DEGREES);
pros::ADIAnalogIn trayPot ('G');
pros::ADIAnalogIn armPot ('F');
pros::ADIEncoder leftEnc ('A','B', false);
pros::ADIEncoder rightEnc ('C','D', true);
pros::ADIEncoder backEnc ('H','I', true);
okapi::MotorGroup leftDrive({9,8});
okapi::MotorGroup rightDrive({-7,-6});
