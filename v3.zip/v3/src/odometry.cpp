#include "main.h"


//================ Odometry Variables ================

const double WHEEL_DIAMETER = 5.33;
const double ENCODER_WIDTH = 10.5;
const double WHEEL_CIRCUMFERENCE = WHEEL_DIAMETER*M_PI;
const int DELAY = 5;

double robotTheta = 0.0;
double robotX = 0.0;
double robotY = 0.0;


void thread_Odometry(void*param)
{

    pros::delay(100);

    robotTheta = 0.0;
    robotX = 0.0;
    robotY = 0.0;

    double dTheta = 0.0;
    double dX = 0.0;
    double dY = 0.0;

    double currentLeft = 0.0;
    double currentRight = 0.0;

    double prevLeft = 0.0;
    double prevRight = 0.0;

    double dLeftVal = 0.0;
    double dRightVal = 0.0;
    lv_obj_t * xLabel = lv_label_create(lv_scr_act(), NULL);
    lv_obj_t * yLabel = lv_label_create(lv_scr_act(), NULL);
    lv_obj_t * thetaLabel = lv_label_create(lv_scr_act(), NULL);
    lv_obj_set_pos(xLabel,10,20);
    lv_obj_set_pos(yLabel,10,40);
    lv_obj_set_pos(thetaLabel,10,60);

    //left.tare_position();
    //right.tare_position();

    leftDrive.tarePosition();
    rightDrive.tarePosition();

    while(true)
    {
        //currentLeft = left.get_position()/360*WHEEL_CIRCUMFERENCE; //read encoders
        //currentRight = right.get_position()/360*WHEEL_CIRCUMFERENCE;
        //divides by 900 because 900 ticks per rotation for 200 rpm cartridge

        currentLeft = leftDrive.getPosition()/360*WHEEL_CIRCUMFERENCE; //read encoders
        currentRight = rightDrive.getPosition()/360*WHEEL_CIRCUMFERENCE;

        dLeftVal = (currentLeft - prevLeft);
        dRightVal = (currentRight - prevRight);

        prevLeft = currentLeft; //update prev values
        prevRight = currentRight;

        dTheta = (dLeftVal - dRightVal) / ENCODER_WIDTH; //calculate change in angle in radians
        robotTheta += dTheta;
        robotTheta = fmod(robotTheta, 2*M_PI);
        if(robotTheta < 0) robotTheta += 2*M_PI;

        dX = (dLeftVal + dRightVal)/2 * sin( (robotTheta) ); //calculate change in x
        dY = (dLeftVal + dRightVal)/2 * cos( (robotTheta) ); //calculate change in y

        robotX += dX; //add to current x and y
        robotY += dY;



        std::string x = std::to_string( robotX );
        char x_array[x.length()+1];

        std::string y = std::to_string( robotY );
        char y_array[y.length()+1];

        std::string theta = std::to_string( robotTheta );
        char theta_array[theta.length() + 1];

        strcpy(x_array,x.c_str());
        strcpy(y_array,y.c_str());
        strcpy(theta_array,theta.c_str());

        lv_label_set_text(xLabel, x_array);
        lv_label_set_text(yLabel, y_array);
        lv_label_set_text(thetaLabel, theta_array);

        pros::delay(10); //reupdate every dT msec
    }
}

double calcDistance(double x1, double y1, double x2, double y2)
{
    return sqrt(pow((y1 - y2), 2) + pow((x1 - x2), 2));
}

double calcDistance(double x2, double y2)
{
  return sqrt(pow((robotY - y2), 2) + pow((robotX - x2), 2));
}

double calcAngleError(double targetX, double targetY)
{
    double radius = calcDistance(robotX, robotY, targetX, targetY);
    double predictedX = radius*sin(robotTheta) + robotX;
    double predictedY = radius*cos(robotTheta) + robotY;
    double chord = calcDistance(predictedX, predictedY, targetX, targetY);

    double angleError = 2*asin( (chord / 2) / (radius) );

    predictedX = radius*sin( fmod(angleError + robotTheta, 2*M_PI) ) + robotX;
    predictedY = radius*cos( fmod(angleError + robotTheta, 2*M_PI) ) + robotY;

    if( (predictedX < targetX + 0.1) && (predictedX > targetX - 0.1) && (predictedY < targetY + 0.1) && (predictedY > targetY - 0.1) )
        return angleError;
    else
        return angleError*-1;
}


//--------------ODOM-----------------
/*const double WHEEL_CIRCUMFERENCE = 4*PI;
const double BACK_TO_TRACKING_LENGTH = 5;
const double RIGHT_TO_TRACKING_LENGTH = 5;
const double DELAY = 5;
double currentLeft = 0;
double currentRight = 0;
double currentBack = 0;
double dLeftVal = 0;
double dRightVal = 0;
double dBackVal = 0;
double prevLeft = 0;
double prevRight = 0;
double prevBack = 0;
double dTheta = 0;
double absTheta = 0;
double prevTheta = 0;
double robotTheta = 0;
double dX = 0;
double dY = 0;
double dOffsetX = 0;
double dOffsetY = 0;
double avgTheta = 0;
double robotX = 0;
double robotY = 0;

double inchesTraveled(double encoderTicks)
{
    return (encoderTicks / 360)*WHEEL_CIRCUMFERENCE;
}

void thread_odometry(void* param){

   leftEnc.reset();
   rightEnc.reset();
   pros::delay(50);
   while(true)
   {
       currentLeft = inchesTraveled(leftEnc.get_value()); //read encoders
       currentRight = inchesTraveled(rightEnc.get_value());
       currentBack = inchesTraveled(backEnc.get_value());
       dLeftVal = (currentLeft - prevLeft);
       dRightVal = (currentRight - prevRight);
       dBackVal = (currentBack - prevBack);

       prevLeft = currentLeft; //update prev values
       prevRight = currentRight;
       prevBack = currentBack;
       dTheta = (dLeftVal - dRightVal) / (RIGHT_TO_TRACKING_LENGTH * 2); //calculate change in angle in radians
       absTheta = prevTheta + dTheta;

       robotTheta += dTheta;
       robotTheta = fmod(robotTheta, 2*M_PI);
       if(robotTheta < 0) robotTheta += 2*M_PI;

       dX = (dLeftVal + dRightVal)/2 * sin( (robotTheta) ); //calculate change in x
       dY = (dLeftVal + dRightVal)/2 * cos( (robotTheta) ); //calculate change in y
       if(dTheta == 0){
         dOffsetX = dBackVal;
         dOffsetY = dRightVal;
       } else{

         dOffsetX = 2 * sin(dTheta/2) * ((dBackVal/dTheta) + BACK_TO_TRACKING_LENGTH);
         dOffsetY = 2 * sin(dTheta/2) * ((dRightVal/dTheta) + RIGHT_TO_TRACKING_LENGTH);
       }

         avgTheta = prevTheta + (dTheta/2);
         double r = sqrt(pow(dOffsetX,2) + pow(dOffsetY,2));
         double tempTheta = acos(dOffsetX/r);
         dX = r*cos(tempTheta + avgTheta);
         dY = r*sin(tempTheta + avgTheta);
         robotX+=dX;
         robotY+=dY;

       pros::delay(DELAY); //reupdate every dT msec
   }
}*/
